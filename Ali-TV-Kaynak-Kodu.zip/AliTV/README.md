# Ali TV

Android telefon ve Android TV için temel IPTV oynatıcı projesi.

## Özellikler
- Kullanıcının girdiği M3U/M3U8 listesini yükleme
- Kanal arama, favoriler
- Basit Türkçe/Kürtçe kategori filtreleri (M3U `group-title` alanına göre)
- ExoPlayer ile HTTP(S) canlı yayın oynatma
- Hesap gerektirmeyen yerel kullanım

Yalnızca izleme hakkına sahip olduğunuz, ücretsiz ve yasal yayın listelerini ekleyin. Proje herhangi bir kanal listesi veya yayın aboneliği içermez.

## APK oluşturma
GitHub'a bu klasörün içeriğini yükleyin. `main` dalına push yaptığınızda veya Actions içinden **Build Ali TV APK** iş akışını çalıştırdığınızda APK üretilir. Çıktı, Actions çalışmasının **Artifacts** bölümünde `Ali-TV-debug-apk` adıyla bulunur.

Bu ilk sürüm geliştirme amaçlı imzasız debug APK üretir. Google Play veya dağıtım için ayrıca release imzalama yapılandırması gerekir.
