package com.alitv.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import android.text.*;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static class Channel {
        String name, url, group;
        Channel(String n, String u, String g){name=n;url=u;group=g;}
    }
    LinearLayout root, listArea;
    EditText urlInput, searchInput;
    TextView status, title;
    PlayerView playerView;
    ExoPlayer player;
    ArrayList<Channel> channels = new ArrayList<>();
    HashSet<String> favorites = new HashSet<>();
    String category = "Tümü";
    SharedPreferences prefs;

    int blue = Color.rgb(28,130,255), bg = Color.rgb(9,16,30), panel = Color.rgb(18,30,51);
    int white = Color.WHITE, muted = Color.rgb(170,190,215);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        prefs=getSharedPreferences("alitv",0);
        favorites.addAll(prefs.getStringSet("favorites",new HashSet<>()));
        buildUI();
        String saved=prefs.getString("playlist","");
        if(!saved.isEmpty()) urlInput.setText(saved);
    }

    void buildUI(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,14,18,12); root.setBackgroundColor(bg);
        setContentView(root);
        title=new TextView(this); title.setText("ALI TV"); title.setTextColor(blue); title.setTextSize(28); title.setTypeface(null,1); root.addView(title);
        TextView sub=new TextView(this); sub.setText("Canlı yayınların • Kendi yasal M3U listen"); sub.setTextColor(muted); sub.setTextSize(13); root.addView(sub);
        LinearLayout add=new LinearLayout(this); add.setOrientation(LinearLayout.HORIZONTAL); add.setPadding(0,10,0,8); root.addView(add);
        urlInput=new EditText(this); urlInput.setSingleLine(true); urlInput.setHint("M3U bağlantısını yapıştır"); urlInput.setTextColor(white); urlInput.setHintTextColor(muted); urlInput.setTextSize(14); urlInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); add.addView(urlInput,new LinearLayout.LayoutParams(0,52,1));
        Button load=button("YÜKLE"); add.addView(load,new LinearLayout.LayoutParams(-2,48)); load.setOnClickListener(v->loadPlaylist(urlInput.getText().toString().trim()));
        status=new TextView(this); status.setText("Henüz liste yüklenmedi. Ücretsiz ve yasal yayın listenin URL'sini ekle."); status.setTextColor(muted); status.setTextSize(12); root.addView(status);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,1); cp.topMargin=10; root.addView(content,cp);
        LinearLayout left=new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.setBackgroundColor(panel); content.addView(left,new LinearLayout.LayoutParams(0,-1,1.05f));
        LinearLayout right=new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setPadding(8,0,0,0); content.addView(right,new LinearLayout.LayoutParams(0,-1,1.5f));
        searchInput=new EditText(this); searchInput.setSingleLine(true); searchInput.setHint("Kanal ara..."); searchInput.setTextColor(white); searchInput.setHintTextColor(muted); left.addView(searchInput,new LinearLayout.LayoutParams(-1,48));
        searchInput.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderChannels();} public void afterTextChanged(Editable e){}});
        HorizontalScrollView hsv=new HorizontalScrollView(this); LinearLayout cats=new LinearLayout(this); cats.setOrientation(LinearLayout.HORIZONTAL); hsv.addView(cats); left.addView(hsv);
        String[] cs={"Tümü","Favoriler","Türkçe","Kürtçe"};
        for(String c:cs){Button b=button(c); b.setTextSize(11); cats.addView(b); b.setOnClickListener(v->{category=c;renderChannels();});}
        ScrollView sv=new ScrollView(this); listArea=new LinearLayout(this); listArea.setOrientation(LinearLayout.VERTICAL); sv.addView(listArea); left.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        playerView=new PlayerView(this); playerView.setUseController(true); right.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=new TextView(this); hint.setText("Kanal seçerek oynat • Favori için ☆"); hint.setTextColor(muted); hint.setTextSize(12); right.addView(hint);
        renderChannels();
    }

    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setTextSize(12); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); return b; }

    void loadPlaylist(String url){
        if(url.isEmpty()){status.setText("Önce M3U bağlantısı gir.");return;}
        status.setText("Liste yükleniyor...");
        new Thread(()->{
            ArrayList<Channel> parsed=new ArrayList<>();
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","AliTV/1.0");
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
                String line,name="Kanal",group="Diğer"; int count=0;
                while((line=r.readLine())!=null){
                    line=line.trim();
                    if(line.startsWith("#EXTINF")){
                        int comma=line.lastIndexOf(','); name=comma>=0?line.substring(comma+1).trim():"Kanal";
                        group="Diğer";
                        int gi=line.indexOf("group-title=\""); if(gi>=0){int st=gi+13,en=line.indexOf('"',st);if(en>st)group=line.substring(st,en);}
                    } else if(!line.isEmpty()&&!line.startsWith("#")&&(line.startsWith("http://")||line.startsWith("https://"))){
                        parsed.add(new Channel(name,line,group)); count++;
                    }
                }
                r.close(); c.disconnect();
                final int loadedCount = count;
                runOnUiThread(()->{channels.clear();channels.addAll(parsed);prefs.edit().putString("playlist",url).apply();status.setText(loadedCount+" kanal yüklendi.");renderChannels();});
            }catch(Exception e){runOnUiThread(()->status.setText("Liste yüklenemedi. URL'yi ve internet bağlantını kontrol et."));}
        }).start();
    }

    void renderChannels(){
        if(listArea==null)return;
        listArea.removeAllViews(); String q=searchInput==null?"":searchInput.getText().toString().toLowerCase(Locale.ROOT); int shown=0;
        for(Channel ch:channels){
            boolean fav=favorites.contains(ch.url);
            if(category.equals("Favoriler")&&!fav)continue;
            if(category.equals("Türkçe")&&!ch.group.toLowerCase(Locale.ROOT).contains("türk"))continue;
            if(category.equals("Kürtçe")&&!ch.group.toLowerCase(Locale.ROOT).contains("kürt")&&!ch.group.toLowerCase(Locale.ROOT).contains("kurd"))continue;
            if(!ch.name.toLowerCase(Locale.ROOT).contains(q)&&!ch.group.toLowerCase(Locale.ROOT).contains(q))continue;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(8,4,6,4);
            TextView n=new TextView(this); n.setText(ch.name+"\n"+ch.group); n.setTextColor(white); n.setTextSize(13); row.addView(n,new LinearLayout.LayoutParams(0,52,1));
            Button f=button(fav?"★":"☆"); row.addView(f); f.setOnClickListener(v->{if(favorites.contains(ch.url))favorites.remove(ch.url);else favorites.add(ch.url);prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();renderChannels();});
            row.setOnClickListener(v->play(ch)); listArea.addView(row); View line=new View(this);line.setBackgroundColor(Color.rgb(40,58,82));listArea.addView(line,new LinearLayout.LayoutParams(-1,1)); shown++;
        }
        if(shown==0){TextView empty=new TextView(this);empty.setText(channels.isEmpty()?"M3U listeni yükleyince kanallar burada görünecek.":"Bu kategoride kanal bulunamadı.");empty.setTextColor(muted);empty.setPadding(12,20,12,12);listArea.addView(empty);}
    }

    void play(Channel ch){
        try{
            if(player==null){player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);}
            player.setMediaItem(MediaItem.fromUri(ch.url));player.prepare();player.play();
            status.setText("Oynatılıyor: "+ch.name);
        }catch(Exception e){status.setText("Kanal açılamadı.");}
    }
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
